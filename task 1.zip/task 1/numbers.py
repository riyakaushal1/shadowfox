
# Define the number_format function
def number_format(num, fmt):
    return format(num, fmt)

print(number_format(145, 'o'))  # octal

# Find pond area
r = 84
pi = 3.14
area = pi * r * r  
print("The area of the pond is:", area)

# bonus ques ans 
water = int (area*1.4)
print("The total amount of water is :",water)
