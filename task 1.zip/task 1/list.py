#calculate the no. of members 
def count_members(members):
    return len(members)
print(count_members(["Superman", "Batmam", "Wonder Woman", "Flash", "Aquaman", "Green Lantern"]))

# Add new members
justice_League = ["Superman", "Batmam", "Wonder Woman", "Flash", "Aquaman", "Green Lantern"]
justice_League.extend(["Batgirl", "Nightwing"])  # Use extend to add multiple members
print(justice_League)


#Make wonder woman as a leader
justice_League[0] = "Wonder Woman"
justice_League[2] = "Superman"
print(justice_League)


# Separation between Aquaman and Flash
justice_League [5] = "Aquaman"
justice_League [4] = "Green Lantern"
print(justice_League)

# Replace the existing members
justice_League = ["Cyborg", "Shazam", "Hawkgirl", "Martian Manhunter", "Green Arrow"]
print(justice_League)

#Alphabetical sorting 
justice_League.sort()
print(justice_League)

#bonus : predict new leader with alphabetical order
print("The new leader is:", justice_League[0])





