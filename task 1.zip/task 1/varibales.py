#create variable name and check datatype
pi = 22/7
print("The value of pi is :",pi)
print("The datatype of pi is : ", type(pi))


# create varibale for assign the value 4
For = 4 # for is a keyword in python so i use For instead of for
print("The value of For is:",For)


#find simple interest
p = 800
R = 6
T = 3
SI = (p*R*T)/100
print("The simple interest is :",SI)


