#calculate BMI through user input
height = float(input("Enter your height in meters: "))
weight = float(input("Enter your weight in kilograms: "))
bmi = weight / (height ** 2)
print(f"Your BMI is: {bmi:.2f}")# f using for formating string9 #2 decimal place
if bmi < 18.5:
    print("You are underweight.")
elif 18.5 <= bmi < 24.9:
    print("You have a normal weight.")
elif 25 <= bmi < 29.9:
    print("You are overweight.")
else:
    print("You are obesity.")

#find countries belongs to through user input 
Australia = ["Sydney", "Melbourne", "Brisbane", "Perth"] 
UAE = ["Dubai", "Abu Dhabi", "Sharjah", "Ajman"] 
India = ["Mumbai", "Bangalore", "Chennai", "Delhi"]

city = input("Enter the name of a city: ")
if city in Australia:
    print(f"{city} is in Australia.")
elif city in UAE:
    print(f"{city} is in UAE.")
elif city in India:
    print(f"{city} is in India.")
else:
    print(f"Sorry, I don't know which country {city} belongs to.")
    



