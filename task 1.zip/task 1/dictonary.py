# friends name and find lenght of names
friends = ["Riya" , "harshita", "Ravinder" , "Rythem" , "nitin" , "shivansh"]
friends_tuples = [(name, len(name)) for name in friends]
print ("friends and lenght of their names :", friends_tuples)

#check who spent more money in trip 
#your expenses
your_expenses = {
    "Hotel": 1200,
    "Food": 800,
    "Transportation": 500,
    "Attractions": 300,
    "Miscellaneous": 200,
}
#partner expenses
partner_expenses = {
    "Hotel": 1000,
    "Food": 900,
    "Transportation": 600,
    "Attractions": 400,
    "Miscellaneous": 150,
}

# Calculate total expenses for both
total_your_expenses = sum(your_expenses.values())
total_partner_expenses = sum(partner_expenses.values())

print("Your total expenses:", total_your_expenses)
print("Partner's total expenses:", total_partner_expenses)


# check who spent more money
if total_your_expenses > total_partner_expenses:
    print("You spent more money on the trip.")
elif total_your_expenses < total_partner_expenses:
    print("Your partner spent more money on the trip.")
else:
    print("Both spent the same amount on the trip.")


# print category and difference in expenses
print("Category-wise expense differences:")
for category in your_expenses:
    difference = your_expenses[category] - partner_expenses.get(category, 0)
    print(f"{category}: {difference}")# f using for formating string 

    